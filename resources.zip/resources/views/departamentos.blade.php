<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ETEC Zona Leste</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* alinhamento à esquerda */
    .logo-container {
      margin-right: auto;}
    .logo-container-2 {
        display: flex;
        flex-direction: column;
        align-items: center }
  </style>
</head>
<body>
<header class="bg-white">
<nav class="bg-black">
        <div class="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
            <div class="relative flex h-16 items-center justify-between">
                <div class="logo-container">
                    <a href="/principal">
                        <h1 class="text-red-800 font-bold text-3xl sm:text-4xl lg:text-2xl">Etec</h1>
                        <span class="text-gray-300 px-2 font-normal sm:inline">Zona Leste</span></a></div>
                <div class="sm:hidden">
                <button type="button" class="mobile-menu-button relative inline-flex items-center justify-center rounded-md p-2 text-white hover:text-white"
                aria-controls="navigation-menu" aria-expanded="false" id="mobile-menu-button">
                        <span class="absolute -inset-0.5"></span>   
                    </button>
                </div>
                <div class="navigation-menu hidden sm:flex flex-1 justify-end items-center space-x-4 relative" id="navigation-menu">
                    <a href="/principal" class="text-gray-300 rounded-md px-3 py-2 text-sm font-medium ml-5"
                     aria-current="page">Início</a>
                    <a href="#"
                        class="text-gray-300 rounded-md px-3 py-2 text-sm font-medium">Cursos</a>
                    <a href="#"
                        class="text-gray-300  rounded-md px-3 py-2 text-sm font-medium">Instituição</a>
                    <a href="/departamentos"
                        class="text-gray-300 rounded-md px-3 py-2 text-sm font-medium">Departamentos</a>
                    <a href="#"
                        class="text-gray-300 rounded-md px-3 py-2 text-sm font-medium">Oportunidades</a>
                    <a href="#"
                        class="text-gray-300 rounded-md px-3 py-2 text-sm font-medium">Vestibulinho</a>
                </div>
            </div>
        </div>
    </nav>
<!-- Banner principal da página: Departamentos-->

<div class="relative isolate overflow-hidden bg-black py-24 sm:py-32 dark:bg-white-dark min-h-[630px] after:content-[''] after:h-full after:w-full after:absolute after:left-0 after:top-0 after:bg-[#1414149c] ">
  <img src="https://www.eteczonaleste.com.br/wp-content/uploads/2023/11/priscilla-du-preez-OEdkPaxYMXU-unsplash-_1_-_1_.webp" alt="" class="absolute inset-0 -z-10 h-full w-full object-cover object-right md:object-center after:bg-[#1414149c]">
  <div class="mx-auto max-w-7xl px-6 lg:px-8">
    <div class="mx-auto max-w-2xl lg:mx-0">
      <h2 class="font-bold text-sm mb-5 z-50 mt-40 ml-14 relative" style="color: #B2B6BB">DEPARTAMENTOS</h2>
      <p class="text-white text-3xl -bottom-2 relative tracking-tight font-bold z-50 ml-14">Coordenação de Cursos & Direção</p>
      <p class="text-white text-lg relative font-normal z-50 ml-14 mt-7">As Coordenações de Curso são responsáveis pelo conjunto de ações destinadas ao planejamento do ensino, à supervisão de sua execução, ao controle das atividades docentes em relação às diretrizes didáticas pedagógicas e administrativas, bem como pela otimização dos recursos físicos e didáticos disponíveis para os cursos mantidos pelas Etecs.</p>
    </div>
    <div class="mx-auto mt-10 max-w-2xl lg:mx-0 lg:max-w-none">
      <div class="grid grid-cols-1 gap-x-8 gap-y-6 text-base font-semibold leading-7 text-white sm:grid-cols-2 md:flex lg:gap-x-10">
      </div>
    </div>
  </div>
</div>
<!-- informações -->
<div class="flex flex-col justify-left md:flex-row items-center mt-50 text--bs-dark p-8 md:px-20">
    <div class="md:w-12/12 md:ml-10 md:order-1">
    <h1 class="text-3xl font-bold mb-4 text--bs-dark">Coordenador Novotec</h1>
    <p class="font-normal text-base text--bs-dark">Giovanna Littiere (Novotec Administração) </br>
          Leandro (Novotec Logística)</br>
          Marcelo Collado (Novotec Desenvolvimento de Sistemas)</br>
          Cibelle Ferreria Francoso (Novotec RH)</br>
          Jeferson Roberto de Lima (Novotec Desenvolvimento de Sistemas AMS)
        </p></div>
</div>

<div class="flex flex-col justify-left md:flex-row items-center mt-5 text-black p-8 md:px-20">
    <div class="md:w-12/12 md:ml-10 md:order-1">
    <h1 class="text-3xl font-bold mb-4 text--bs-dark">Coordenador Curso Técnico</h1>
    <p class="font-normal text-base text--bs-dark">Monyse Tesser Panacci (Técnico em Adminstração / Técnico em Contabilidade) </br>
          Ediney Ciasi Barreto (Técnico em Desenvolvimento de Sistemas)</br>
          Silvano Lack de Brito (Técnico em Logística / Técnico em Serviços Jurídicos)
      </p></div>
</div>

<div class="flex flex-col justify-left md:flex-row items-center mt-5 text-black p-8 md:px-20">
    <div class="md:w-12/12 md:ml-10 md:order-1">
        <h1 class="text-3xl font-bold mb-4 text--bs-dark ">Contato</h1>
        <p class="font-normal text-base text--bs-dark">Telefones: (11) 2045-4018 | (11) 2045-4016 | (11) 2045-4011
        <p class="font-normal text-base text--bs-dark">E-mail:<span class="text-blue-400"><a href=""> e211dir@cps.sp.gov.br</a></span>
        </p></div>
</div>

<div class="flex flex-col justify-left md:flex-row items-center mt-5 text-black p-8 md:px-20">
    <div class="md:w-12/12 md:ml-10 md:order-1">
        <h1 class="text-3xl font-bold mb-4 text--bs-dark">Diretor(a) da Etec</h1>
        <p class="font-normal text-base text--bs-dark">Amanda Bueno  
        </p></div>
</div>

<div class="flex flex-col justify-left md:flex-row items-center mt-5 text-black p-8 md:px-20">
    <div class="md:w-12/12 md:ml-10 md:order-1">
        <h1 class="text-3xl font-bold mb-4 text--bs-dark">Assessor Técnico Administrativo II </h1>
        <p class="font-normal text-base text--bs-dark">Patrick Moreno da Silva  
        </p></div>
</div>
<!-- rodapé da página: Departamentos -->
<footer class="bg-gray-100 dark:bg-black">
    <div class="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
        <div class="flex justify-center text-gray-600 dark:text-teal-300">
            <div class="logo-container-2 text-center">
                <h1 class="text-red-800 font-bold text-3xl">Etec</h1>
                <span class="text--bs-dark-300 px-6 font-normal">Zona Leste</span>
            </div>
        </div>
    <p class="mx-auto mt-6 max-w-md text-center leading-relaxed text--bs-dark-500 dark:text-gray-400">
    © 2024 Etec Zona Leste. Todos os direitos reservados.
      Desenvolvido por João Vitor - 3º DS Manhã
    </p>

    <ul class="mt-12 flex flex-wrap justify-center gap-6 md:gap-8 lg:gap-12">
      <li>
        <a
          class="text-gray-700 transition hover:text-gray-700/75 dark:text-white dark:hover:text-white/75"
          href="/principal"
        >Início</a></li>
      <li>
        <a
          class="text-gray-700 transition hover:text-gray-700/75 dark:text-white dark:hover:text-white/75"
          href="#"
        >Cursos</a></li>
      <li>
        <a
          class="text-gray-700 transition hover:text-gray-700/75 dark:text-white dark:hover:text-white/75"
          href="#"
        >Instituição</a></li>
      <li>
        <a
          class="text-gray-700 transition hover:text-gray-700/75 dark:text-white dark:hover:text-white/75"
          href="/departamentos"
        >Departamentos</a></li>
      <li>
        <a
          class="text-gray-700 transition hover:text-gray-700/75 dark:text-white dark:hover:text-white/75"
          href="#"
        >Oportunidades</a></li>
      <li>
        <a
          class="text-gray-700 transition hover:text-gray-700/75 dark:text-white dark:hover:text-white/75"
          href="#"
        >Vestibulinho</a></li>
    </ul>      
</footer>
</header>
</html>